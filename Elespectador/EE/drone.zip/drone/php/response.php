<?php
/*
 Script respuesta para formularios pagina el espectador.com, promocion DRONES
 */


//ini_set('error_reporting', E_ALL);
//error_reporting(0);
include("bd.php");
if ($_POST['action']){
$func=$_POST['action'];
eval("$func;");
exit;
}

/*
Funcion devuelve codigo html de los menu de opciones de los formularios para la promocion del drone.
*/
function combos($activ=0){
$rwllmx=Array();$rwllmx=explode(" as ",$_POST['llve']);
$where=strtr(utf8_decode($_POST['where']), "������������", "aeiouAEIOUnN");
$query_m= sprintf("SELECT %s FROM %s WHERE %s  ORDER BY %s",mysql_real_escape_string($_POST['primary'].$_POST['llve']),mysql_real_escape_string($_POST['tabla']),mysql_real_escape_string($where),mysql_real_escape_string($_POST['order']));
$query_m=str_replace("#1","'%",$query_m);$query_m=str_replace("#2","%'",$query_m);
$codCmbo="<select id='combo_".$_POST['cmbid']."' name='combo_".$_POST['cmbid']."' class='mdl-selectfield__select'>";
if ($_POST['primary']) $primaria=rtrim($_POST['primary'],",");
else $primaria=$rwllmx[1];
if ($_POST['fisrt']) $codCmbo.="<option value='0' selected>".$_POST['fisrt']."</option>";
$resukt_m=mysql_query($query_m);
if ($resukt_m){
while($rowPrin = mysql_fetch_array($resukt_m,MYSQL_ASSOC)){
$codCmbo.="<option value='".utf8_encode(trim($rowPrin[$primaria]))."'>".ucfirst(utf8_encode(cortador($rowPrin[$rwllmx[1]],30)))."</option>";
}}
$codCmbo.="</select>";
if ($activ==1) return $codCmbo;
else {echo $codCmbo;}
}

/*
 Funcion devuelve codigo html con la informacion del punto del almacen que el usuario interesado debe tramitar su  reserva.
*/
function lddir(){
echo '<input type="text" name="direccion" id="direccion" value="'.implode("",mysql_fetch_array(mysql_query("SELECT direccion FROM  `drone_puntos` WHERE  `cod_almacen` =".$_POST['idalm']),MYSQL_ASSOC)).'" readonly><label for="direccion">Direcci&oacute;n punto de redenci&oacute;n</label>';
}

function cortador($input, $length) {
if (strlen($input) <= $length) {return $input;}
$last_space = strrpos(substr($input, 0, $length), ' ');
$trimmed_text = substr($input, 0, $last_space);
if ($ellipses) {$trimmed_text .= '...';	}
return $trimmed_text;
}

/*
 Funcion insertar en las diferentes tablas de la base de datos, la informacion de los usuarios y de las reservas, verificacion de campos diligenciado por los usuarios
 */
function editBds($tabla){
global $alert, $iserror;
date_default_timezone_set('America/Bogota');
$_POST['fecha']=date('Y-m-d H:i:s');
$query =  "INSERT INTO ".$tabla." (";
$queryKey="SHOW COLUMNS FROM ".$tabla;
$resultKey=mysql_query($queryKey);
$segund="VALUES (";
while ($prowK=mysql_fetch_array($resultKey)){
if ($_POST[$prowK['Field']]){
if ( preg_match( "/[][{}()*+?.\\^$|]/i", $_POST[$prowK['Field']] ) && $prowK['Field']!="email" && $prowK['Field']!="direccion_usuario") {
	if($prowK['Field']!="id" && $prowK['Field']!="almacen_code" && $prowK['Field']!="direccion"){$iserror = 1;$alert .= "<li><h6>Campo " . $prowK['Field'] . " con caracteres invalidos!!</h6></li>";}
}
else{
$query .=  "`".$prowK['Field']."`, ";
$segund.="'".utf8_decode($_POST[$prowK['Field']])."', ";
}}
elseif($prowK['Field']!="id" && $prowK['Field']!="vendedor" && $prowK['Field']!="id_reserva"){
$iserror = 1;
if ($prowK['Field']=="almacen_code") $prowK['Field']="Punto Almacen";
if (substr_count($alert,$prowK['Field'])==0) $alert .= "<li><h6>Campo " . ucwords(str_replace("_"," ",str_replace("telefono","celular",$prowK['Field']))) . " invalido!!</h6></li>";
}
if($prowK['Field']=="telefono" || $prowK['Field']=="cedula") {
	if (!is_numeric($_POST[$prowK['Field']]) && substr_count($alert,$prowK['Field'])==0) {$iserror = 1;$alert .= "<li><h6>N&uacute;mero " . ucwords(str_replace("_"," ",str_replace("telefono","celular",$prowK['Field']))) . " invalido debe ser num&eacute;rico!!</h6></li>";}
}
if($prowK['Field']=="nombres" || $prowK['Field']=="apellidos") {
$PtVal= strtr(utf8_decode($_POST[$prowK['Field']]), "������������ ", "aeiouAEIOUnNA");
if (preg_match("/\W|\d/i",$PtVal) && substr_count($alert,$PtVal)==0) {$iserror = 1;$alert .= "<li><h6> " . ucwords(str_replace("_"," ",$PtVal)) . " invalido debe contener caracteres validos!!</h6></li>";}
}
if(strlen($_POST['telefono'])!=10 && $prowK['Field']=="telefono" && substr_count($alert,"celular")==0){$iserror = 1;$alert .= "<li><h6>N&uacute;mero celular invalido debe contener 10 digitos!!</h6></li>";}
if($prowK['Field']=="vendedor" && $_POST['vendedor']=="null") {$iserror = 1;$alert .= "<li><h6>Campo " . ucwords(str_replace("_"," ",$prowK['Field'])) . " invalido!!</h6></li>";}
}
if ($_POST['habeas']!="ok" && $_POST['action']=="registro()"){$iserror = 1;$alert .= "<li><h6>Campo acepto politicas invalido!!</h6></li>";}
$query=rtrim($query,", ");
$segund=rtrim($segund,", ");
$segund.=")";
 $query.=") ".$segund;
if ($iserror==0) {
if (mysql_query($query)) {
if ($tabla=="drone_registro") {$_SESSION["user"] = mysql_insert_id();}
    $_POST['punto']=implode("",mysql_fetch_array(mysql_query("SELECT almacen FROM  `drone_puntos` WHERE  `cod_almacen` =".$_POST['combo_puntos']),MYSQL_ASSOC));
if ($tabla=="drone_usuario_punto") $_POST['id_reserva']=sprintf("%04s", mysql_insert_id());
$alert='Gracias!, su reserva ha sido exitosa';
}
else {$iserror=1;$alert="<div class=\"alert_title\"><h4>Error al ingresar los campos</h4></div>";}
}
}
/*
Registro de usuarios, reenvio funcion verificacion de correo electronico
*/
function registro() {
global $iserror,$alert;
if (check_email_address($_POST['email'])){
$rvsn=revdoc();
if ($rvsn) {
editBds('drone_registro');
if ($iserror==1) displayAlert();
else{
$_POST['usuario_id']=$_SESSION["user"];
editBds('drone_usuario_punto');
if (!$_POST['direccion']) {$iserror=0;$alert="Campos datos personales dilenciados correctamente!!<br><span style='color:Red'>Punto de redenci&oacute;n no seleccionado</span>";}
displayAlert();
}
}
}
else{$alert='Correo electr&oacute;nico invalido';$iserror=1;displayAlert();}
}
/*
 Funcion Revision de correo electronico diligenciado por el usuario
*/
function check_email_address($email) {
if (!ereg("^[^@]{1,64}@[^@]{1,255}$", $email)) {return false;}
$email_array = explode("@", $email);
$local_array = explode(".", $email_array[0]);
for ($i = 0; $i < sizeof($local_array); $i++) {
if (!ereg("^(([A-Za-z0-9!#$%&'*+/=?^_`{|}~-][A-Za-z0-9!#$%&
?'*+/=?^_`{|}~\.-]{0,63})|(\"[^(\\|\")]{0,62}\"))$",$local_array[$i])) {return false;}
}
if (!ereg("^\[?[0-9\.]+\]?$", $email_array[1])) {
$domain_array = explode(".", $email_array[1]);
if (sizeof($domain_array) < 2) {
return false;
}
for ($i = 0; $i < sizeof($domain_array); $i++) {
if (!ereg("^(([A-Za-z0-9][A-Za-z0-9-]{0,61}[A-Za-z0-9])| ?([A-Za-z0-9]+))$",$domain_array[$i])) {return false;}}}
return true;
}

/*
Funcion revision documento del usuario si existe en la base de datos
*/
function revdoc(){
$qrvrf="SELECT id,cedula FROM drone_registro WHERE cedula='".$_POST['cedula']."'";
$conteo=mysql_num_rows(mysql_query($qrvrf));
if (($conteo>0 && $_POST['action']=="registro()") || ($conteo==0 && $_POST['action']=="entrada()")){
$msg= $_POST['action']=="registro()" ? "Usuario o correo existente" : "Usuario inexistente";
echo "<script>$('.personales').show();$('.nivo-lightbox-close').trigger( 'click' );document.cargando='off';$('.nivo-lightbox-overlay').hide();$(\"#message\").removeClass(\"success\").addClass(\"warning\").stop().slideDown(\"normal\").fadeIn(\"normal\").delay(5000).slideUp(\"normal\");</script>";
echo "<div class=\"alert alert-block alert-danger\">";
echo "<div data-icon=\"&#xe441;\" class=\"alert_icon\"></div>";
echo "<div class=\"alert_title\"><h4>$msg!!</h4></div><br />";
echo "</div>";exit;
}
return true;
}

/*
 Funcion insertar reserva en la base de datos
 */

function entrada(){
global $alert, $iserror;
$rvsn=revdoc();
if ($rvsn){
$iserror=0;
$_POST['usuario_id']=implode("",mysql_fetch_array(mysql_query("SELECT id FROM  `drone_registro` WHERE cedula='".$_POST['cedula']."' LIMIT 1"),MYSQL_ASSOC));
$_POST['nombres']=implode("",mysql_fetch_array(mysql_query("SELECT nombres FROM  `drone_registro` WHERE cedula='".$_POST['cedula']."' LIMIT 1"),MYSQL_ASSOC));
$_POST['email']=implode("",mysql_fetch_array(mysql_query("SELECT email FROM  `drone_registro` WHERE cedula='".$_POST['cedula']."' LIMIT 1"),MYSQL_ASSOC));
editBds('drone_usuario_punto');
if ($iserror==1) {displayAlert();}
else {$alert="Reserva ingresada con exito!!";displayAlert();}
echo '<script>$(".personales").hide();$("#btn_cedula").hide();$("#action").val("entrada()");$("input:text[name=cedula]").val('.$_POST['cedula'].');</script>';
}
}

/*
Funcion mostrar alertas y/o errores, arrejados por los diferentes eventos del script.
*/

function displayAlert(){
global $alert, $iserror;
 if ($iserror==1 ) {
echo "<script>$('.nivo-lightbox-close').trigger( 'click' );document.cargando='off';$('.nivo-lightbox-overlay').hide();$(\"#message\").addClass(\"warning\").stop().slideDown(\"normal\").fadeIn(\"normal\").delay(5000).slideUp(\"normal\");</script>";
echo "<div class=\"alert alert-block alert-danger\">";
echo "<div data-icon=\"&#xe441;\" class=\"alert_icon\"></div>";
echo "<div class=\"alert_title\"><h4>Por favor diligencie completamente el formulario</h4></div><br />";
echo "<ul class=\"unordered\">";
echo $alert;
echo "</ul>";
echo "</div>";
}
else{
echo "<script>$('#btn_cedula').hide();$('#btn_cerrar').show();$('.nivo-lightbox-close').trigger( 'click' );document.cargando='off';$('.nivo-lightbox-overlay').hide();$(\"#message\").addClass(\"success\").stop().slideDown(\"normal\").fadeIn(\"normal\");</script>";
echo "<div class=\"alert alert-block alert-success\">";
//echo "<button type=\"button\" class=\"close\" data-dismiss=\"alert\"><i class=\"icon-cross\"></i></button>";
echo "<div data-icon=\"&#xe245;\" class=\"alert_icon\"></div>";
if (substr_count($alert,'dilenciados correctamente')==0){
$pralert=sndmail();
if (!$pralert) echo "<h4>Falla al enviar el correo con la reserva!!</h4>".$pralert;
else echo $alert."<br><br>".$pralert;
}
else{echo "<h4>$alert</h4>";}
echo "</div>";
if ($_POST['vendedor']){
echo "<script>
$('#btn_cerrarven').show();$('#btn_cerrar').hide();
</script>";
}
else{
echo "<script>
$('#contact-form input[type=text], #contact-form textarea').val('');
$('.personales').hide();$('#btn_cedula').hide();$('#action').val('entrada()');
$('input:text[name=cedula]').val('".$_POST['cedula']."');
$('#combo_ciudad').prop('selectedIndex',0);$('#div_puntos').html('');$('#direscon').hide();
</script>";
}}
exit;
}
/*
 Funcion envio de correo al usuario participante con  la informacion de la reserva, fecha de redencion,
 */
function sndmail(){
require_once( 'api/sendpulseInterface.php' );
require_once( 'api/sendpulse.php' );
define( 'API_USER_ID', '0b763b34fd16b33854b6a76c3b13a0da' );
define( 'API_SECRET', 'f786008f676aa986b5afc3ad2638915e' );
define( 'TOKEN_STORAGE', 'file' );
$SPApiProxy = new SendpulseApi( API_USER_ID, API_SECRET, TOKEN_STORAGE );

foreach($_POST as $ky => $val){${$ky}=($val);}
$body             = file_get_contents('../mail/finalistas_salud_bienestar.html');
$body             = eregi_replace("[\]",'',$body);
$conteo=implode("",mysql_fetch_array(mysql_query("SELECT COUNT(*) as cuenta FROM  `drone_usuario_punto` WHERE 1"),MYSQL_ASSOC));
if ($conteo<1301) $fecha_redencion='2016-12-10';
if ($conteo>1300) $fecha_redencion='2016-12-11';
if ($conteo>2600) $fecha_redencion='2016-12-12';
if ($conteo>3900) $fecha_redencion='2016-12-13';
if ($conteo>5200) $fecha_redencion='2016-12-14';
if ($conteo>6500) $fecha_redencion='2016-12-15';
if ($conteo>7000) $fecha_redencion='Lista de espera';

if ($conteo>5000) {
$tabla_espera=preg_replace("/(.*?)<\!--Content start-->(.*?)<\!--table-->.*/is","\\2",$body);
$tabla_espera=strip_tags($tabla_espera,"<table><tr><td><strong><br>");
$tabla_espera=str_replace("#959595","#ffffff",str_replace("width=\"600\"","",$tabla_espera))."<br>";
$tabla_espera=str_replace("#666666","#ffffff",$tabla_espera);
$tabla_espera=str_replace("100%","400",$tabla_espera);
$tabla_espera=preg_replace("/\[# (.*?) #\]/e", "$\\1", $tabla_espera);
}
elseif($conteo>6000){
$cntDiv=preg_replace("/(.*?)<td align=\"center\" valign=\"top\" class=\"main\"(.*?)>(.*?)<\/td>.*/is","\\3",$body);
$body=str_replace($cntDiv,"Hola, <strong>[# nombres #]</strong>,<br /> <br />su reserva fue exitosa. <br>En las pr�ximas horas enviaremos los datos de su reserva",$body);
return $body;exit;
//
}

$body=preg_replace("/\[# (.*?) #\]/e", "$\\1", $body);
$tabla=preg_replace("/(.*?)<\!--table-->(.*?)<\!--\/table-->.*/is","\\2",$body);

$email = array(
        'html' => $body,
        'text' => 'Para ver el mensaje, por favor, utilice un visor de HTML de correo electr�nico compatibles!',
        'subject' => utf8_encode('Confirmaci�n Reserva Drone 6 H�lices'),
        'from' => array(
            'name' => 'El Espectador Servicio al Cliente',
            'email' => 'john.arevalo@2kstudio.com'
        ),
        'to' => array(
            array(
                'name' => $nombres,
                'email' => $email
            )
        )
    );
    if ($SPApiProxy->smtpSendMail($email))	return $tabla_espera.str_replace("#959595","#ffffff",str_replace("width=\"500\"","",$tabla));
	else {return str_replace("#959595","#f9ffb2",str_replace("width=\"500\"","",$tabla));}
}
?>