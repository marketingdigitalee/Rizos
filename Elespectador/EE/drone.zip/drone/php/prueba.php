<?
ini_set('error_reporting', E_ALL);
error_reporting(0);

require_once( 'api/sendpulseInterface.php' );
    require_once( 'api/sendpulse.php' );

    // https://login.sendpulse.com/settings/#api
    define( 'API_USER_ID', '0b763b34fd16b33854b6a76c3b13a0da' );
    define( 'API_SECRET', 'f786008f676aa986b5afc3ad2638915e' );

    define( 'TOKEN_STORAGE', 'file' );

    $SPApiProxy = new SendpulseApi( API_USER_ID, API_SECRET, TOKEN_STORAGE );

    // Get Mailing Lists list example
    //var_dump( $SPApiProxy->listAddressBooks() );

    // Send mail using SMTP
    $email = array(
        'html' => '<p>Hello!</p>',
        'text' => 'text',
        'subject' => 'Mail subject',
        'from' => array(
            'name' => 'John',
            'email' => 'john.arevalo@2kstudio.com'
        ),
        'to' => array(
            array(
                'name' => 'Juan',
                'email' => 'juanpablo@lalupa.com'
            )
        )       
    );
    var_dump($SPApiProxy->smtpSendMail($email));
?>