<?php

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'vea';
mysql_connect($DB_HOST, $DB_USER, $DB_PASS) or die ("Unable to connect to the database");
mysql_select_db($DB_NAME) or die ("Unable to select the database");

session_start();
/*
$DB_HOST = 'mysql1206.ixwebhosting.com';
$DB_USER = 'tecnija_deporte';
$DB_PASS = 'DePortes1';
$DB_NAME = 'tecnija_espectador';
mysql_connect($DB_HOST, $DB_USER, $DB_PASS) or die ("Unable to connect to the database");
mysql_select_db($DB_NAME) or die ("Unable to select the database");
*/
?>